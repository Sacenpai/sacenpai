<nav class="pagination">	
	<?php $this->pageNav('<i class="fa fa-angle-double-left"></i>', '<i class="fa fa-angle-double-right"></i>'); ?>
</nav>