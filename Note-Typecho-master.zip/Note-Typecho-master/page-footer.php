	<div style="clear:both;"></div>
<footer class="page-footer">
	<p>Copyright @ <?php echo(date("Y")) ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a></p>
	<p><?php if ($this->options->socialicp); ?><a target="_blank" href="http://www.miitbeian.gov.cn/"><?php $this->options->socialicp(); ?></a> | <?php endif; ?>
    Powered by <a href="http://typecho.org" target="_blank">Typecho</a>,Theme <a target="_blank" href="https://note.isweic.com/themes-note/">Note</a>.</p>
</footer>
